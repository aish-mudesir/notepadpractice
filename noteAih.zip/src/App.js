// App.js
import React from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";
import Header from "./components/Header";
import AddNote from "./components/AddNote";
import AppLayout from "./AppLayout";
import Home from "./components/Home";

function App() {
  return (
    <Router>
      <Routes>
        <Route element={<AppLayout />}>
          <Route index element={<Navigate replace to="/home" />} />
          <Route path="/home" element={<Home />} />
          <Route path="/add-note" element={<AddNote />} />
          <Route path="/add-note/:id?" element={<AddNote />} />
        </Route>
      </Routes>
    </Router>
  );
}

export default App;
// ParentComponent.js
import React, { useState } from 'react';
import AddNote from './AddNote';
import Notes from './Notes';

function ParentComponent() {
  const [notes, setNotes] = useState([]);

  return (
    <div>
      <AddNote setNotes={setNotes} />
      <Notes notes={notes} setNotes={setNotes} />
    </div>
  );
}

export default ParentComponent;




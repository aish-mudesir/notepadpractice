import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { FaPenSquare } from 'react-icons/fa';

function Notes({ notes, setNotes }) {
  const [selectedNote, setSelectedNote] = useState(null);

  const handleNoteClick = (note) => {
    setSelectedNote(note);
  };

  const handleDelete = () => {
    // Confirm deletion and delete the selected note
    const isConfirmed = window.confirm('Are you sure you want to delete this note?');
    if (isConfirmed && selectedNote) {
      const updatedNotes = notes.filter((n) => n.id !== selectedNote.id);
      setNotes(updatedNotes);
      localStorage.setItem('notes', JSON.stringify(updatedNotes));
      setSelectedNote(null);
    }
  };

  return (
    <div>
      <div className="left-tag">
        <div>Notes</div>
        <div className="pen-icon-container">
          <Link to="/add-note" className="add-note-link">
            <FaPenSquare className="pen-icon" />
          </Link>
        </div>
      </div>
      <div className="notes-list">
        {notes && notes.length > 0 ? (
          // Check if notes array is defined and not empty
          notes.map((note) => (
            <div key={note.id} className="note-item" onClick={() => handleNoteClick(note)}>
              <h3>{note.title}</h3>
              <p>written by: {note.author}</p>
            </div>
          ))
        ) : (
          // Render a message if notes array is undefined or empty
          <div className="note-item">No notes available</div>
        )}
      </div>
      {selectedNote && (
        <div className="selected-note">
          <h2>{selectedNote.title}</h2>
          <p>Body: {selectedNote.body}</p>
          <p>Author: {selectedNote.author}</p>
          <button onClick={() => setSelectedNote(null)}>Close</button>
          <button onClick={handleDelete}>Delete</button>
          <Link to={`/add-note/${selectedNote.id}`}>
            <button>Edit</button>
          </Link>
        </div>
      )}
    </div>
  );
}

export default Notes;



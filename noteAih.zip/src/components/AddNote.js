// AddNote.js
import React, { useState } from 'react';

function AddNote({ setNotes }) {
  const [note, setNote] = useState({ title: '', body: '', author: '' });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNote((prevNote) => ({
      ...prevNote,
      [name]: value,
    }));
  };

  const handleSubmit = () => {
    const newNote = { ...note, id: Date.now() }; // Assign a unique ID
    setNotes((prevNotes) => [...prevNotes, newNote]); // Update notes state
    localStorage.setItem('notes', JSON.stringify([...prevNotes, newNote])); // Update local storage
    // Clear the form after submitting
    setNote({ title: '', body: '', author: '' });
  };

  return (
    <div>
      <div className="center-container">
        <div className="note-adder">
          <div className="add-note-container">
            <form>
              <label>Note Title<br />
                <input type="text" name="title" value={note.title} onChange={handleChange} />
              </label>
              <br />
              <label>Note Body 😊<br />
                <textarea name="body" value={note.body} onChange={handleChange} />
              </label>
              <br />
              <label>Author<br />
                <select name="author" value={note.author} onChange={handleChange}>
                  <option value="fuad">Fuad</option>
                  <option value="Amir">Amir</option>
                  <option value="rufeyda">Rufeyda</option>
                  <option value="kebede">Kebede</option>
                </select>
              </label>
              <br />
              <button type="button" onClick={handleSubmit}>Add Note</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AddNote;







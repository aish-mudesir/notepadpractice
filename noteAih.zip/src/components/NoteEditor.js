// import React from 'react';
// import { Link } from 'react-router-dom';
// import "../components/styles/NoteEditor.css";

// function NoteEditor() {
//   return (
//     <div className="note-editor-container">
//       <h3>Notes</h3>
//       <Link to="/edit">
//         <span className="pen-icon" role="img" aria-label="Edit Note">✏️</span>
//       </Link>
//     </div>
//   );
// }

// export default NoteEditor;
